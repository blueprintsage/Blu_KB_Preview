# PASS — Consumption Contract (using the library, not just building it)

status: active
owner: docs/domains/spec
last_reviewed: 2026-07-31

Everything else in PASS governs **extraction** — how a source becomes grounded
skill objects. This governs **use**: how a model (SkillForge, or any model doing
real work) draws on those objects. The two are separate contracts with separate
failure modes. Extraction fails by fabricating; consumption fails by ignoring the
library and improvising from priors — the same instinct, one step later.

The goal is to make the model learn and work the way a person who was *taught* the
craft does: consult what you were taught first, start from foundations, use only
what the task needs.

---

## The golden-truth rule

**On any task, check the library for a matching skillset before using your own
knowledge. If a skill covers the task, it is authoritative — the golden truth —
and overrides your prior. Your own knowledge is the fallback only where the
library is silent.**

This inversion is the whole point. An untaught model answers from a diffuse
average of its training data. A taught one answers from the specific, grounded,
source-checked skill it was given. When the two disagree, the skill wins, because
the skill is the part that was verified against a real source and a real craft.

If no skill matches, say so and fall back to your own reasoning — but a silent
fallback that *looks* like it used a skill is the consumption version of a skim.

## Select by task — load the relevant subset, not the library

You do not use every skill for every job. Debugging work does not pull
random-number-generation skills; inking a comic panel does not pull perspective-
grid skills. Match the task to a package and topic path (and tags), retrieve that
skillset, and load only it. Dumping the whole library is both wasteful and a way
to end up applying an irrelevant skill because it was in context.

Retrieval is bounded, the same way extraction's placement step is: pull the
handful of skills whose `IF` clauses plausibly match the situation, not everything
under a package.

## Foundations first, in stage order — never start at step 3

A person drawing a figure does not begin at step 3. They thumbnail the intent,
lay a skeleton, block it with simple solids, tighten, then finalize. A person
writing code does not begin at the special case. The model works the same way:

1. **Foundations before specializations.** Within a selected skillset, load and
   apply the foundation skills before their specializations. `foundation_role`,
   `foundation_object_id`, and `prerequisite_for` links encode this order; honor
   it. A specialization applied without its foundation is a step-3 start.
2. **The universal stage scaffold is the spine.** Run work through
   `0 design → 1 skeleton → 2 block → 3 rough → 4 final` (the mandatory
   `metaskills/iterative-construction` AP). Each skill's `stage_binding` says where
   it belongs in that arc; apply it at its stage, not before.

This is not style. Starting from foundations in stage order is what stops the
model from producing confident, detailed output that is structurally wrong —
the code equivalent of a beautifully rendered hand with six fingers.

## Visual skills require their reference

A visual skill without its reference image is non-teaching — a label, not a
skill. Do not apply a visual card by its text alone. The reference must be present
original art generated from the source renders and card text, and released by
`tools/verify_references.py`; the model works *against* that reference the way an
artist works from life or from a master study. No passing reference, no
application.

## Use-time guardrails

Consumption needs its own gate, parallel to the grounding gate for extraction:

- **Prerequisite enforcement.** A specialization does not load until its foundation
  is loaded.
- **IF-match.** Apply a skill only when its `IF` clause actually matches the
  situation, not because it was retrieved.
- **Confidence surfaced.** A `low`/`medium`-confidence skill is applied as such,
  not trusted like a `high` one.
- **Provenance available.** The source and locator travel with the skill so a human
  can check it.

## Ceiling — enforce, do not ask

Every rule here is one a model can rationalize past, exactly like "don't skim."
So the durable version of this contract is **loader-enforced** — SkillForge
mechanically checks for a matching skill, loads foundations first, blocks a
specialization without its foundation, and refuses a visual skill with no
reference — rather than trusting the model to remember. Prose is the spec; the
loader is the control surface. Until the loader enforces a rule, treat it as a
known gap, not a solved one.
